create
    definer = root@localhost procedure sp_usuarios_insert(IN pdeslogin varchar(64), IN pdessenha varchar(256))
BEGIN
INSERT INTO tb_usuarios (deslogin, dessenha) VALUES (pdeslogin, pdessenha);
SELECT * FROM tb_usuarios WHERE idusuario = last_insert_id();
END;

